package com.javasample.springrest.mysql.model;

@Entity
@Table(name="user_role")
public class UserRole 
{
	@Id  
    @GeneratedValue(strategy=GenerationType.AUTO)  
	private int user_role_id;
	@Column
	private String proxy_user_id;
	@Column
	private String created_dt;
	@Column
	private String created_by;
	@Column
	private String update_by;
	@Column
	private String update_dt;
	@Column
	private String status;
	@Column
	private String region;
	
	@OneToOne(targetEntity=User.class)  
	private User user;
	
	
	public int getUser_role_id() {
		return user_role_id;
	}
	public void setUser_role_id(int user_role_id) {
		this.user_role_id = user_role_id;
	}
	public String getProxy_user_id() {
		return proxy_user_id;
	}
	public void setProxy_user_id(String proxy_user_id) {
		this.proxy_user_id = proxy_user_id;
	}
	public String getCreated_dt() {
		return created_dt;
	}
	public void setCreated_dt(String created_dt) {
		this.created_dt = created_dt;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public String getUpdate_by() {
		return update_by;
	}
	public void setUpdate_by(String update_by) {
		this.update_by = update_by;
	}
	public String getUpdate_dt() {
		return update_dt;
	}
	public void setUpdate_dt(String update_dt) {
		this.update_dt = update_dt;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String toString() {
		return "UserRole [user_role_id=" + user_role_id + ", proxy_user_id="
				+ proxy_user_id + ", created_dt=" + created_dt
				+ ", created_by=" + created_by + ", update_by=" + update_by
				+ ", update_dt=" + update_dt + ", status=" + status
				+ ", region=" + region + ", user=" + user + "]";
	}
}
