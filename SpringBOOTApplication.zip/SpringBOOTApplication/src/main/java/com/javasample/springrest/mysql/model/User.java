package com.javasample.springrest.mysql.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user")
public class User 
{
	@Id  
    @GeneratedValue(strategy=GenerationType.AUTO)  
    @PrimaryKeyJoinColumn  
	private int userId;
	
	@Column
	private String active;
	@Column
	private String cecId;
	@Column
	private String firstname;
	@Column
	private String lastname;
	@Column
	private String region;
	@Column
	private String theater;
	@Column
	private String created_dt;
	@Column
	private String created_by;
	@Column
	private String update_by;
	@Column
	private String update_dt;
	@Column
	private int id;
	
	@OneToOne(targetEntity=UserRole.class,cascade=CascadeType.ALL)  
	private UserRole userRole;
	
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getCecId() {
		return cecId;
	}
	public void setCecId(String cecId) {
		this.cecId = cecId;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getTheater() {
		return theater;
	}
	public void setTheater(String theater) {
		this.theater = theater;
	}
	public String getCreated_dt() {
		return created_dt;
	}
	public void setCreated_dt(String created_dt) {
		this.created_dt = created_dt;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public String getUpdate_by() {
		return update_by;
	}
	public void setUpdate_by(String update_by) {
		this.update_by = update_by;
	}
	public String getUpdate_dt() {
		return update_dt;
	}
	public void setUpdate_dt(String update_dt) {
		this.update_dt = update_dt;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public UserRole getUserRole() {
		return userRole;
	}
	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}
	public String toString() {
		return "User [userId=" + userId + ", active=" + active + ", cecId="
				+ cecId + ", firstname=" + firstname + ", lastname=" + lastname
				+ ", region=" + region + ", theater=" + theater
				+ ", created_dt=" + created_dt + ", created_by=" + created_by
				+ ", update_by=" + update_by + ", update_dt=" + update_dt
				+ ", id=" + id + ", userRole=" + userRole + "]";
	}
}
