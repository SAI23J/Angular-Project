import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { userservice } from '../user.service';

@Component({
  selector: 'search-users',
  templateUrl: './search-users.component.html',
  styleUrls: ['./search-users.component.css']
})
export class SearchUsersComponent implements OnInit {

  userid: number;
  users: User[];

  constructor(private dataService: userservice) { }

  ngOnInit() {
    this.userid = 0;
  }

  private searchusers() {
    this.dataService.getuserById(this.userid)
      .subscribe(users => this.users = users);
  }

  onSubmit() {
    this.searchusers();
  }
}
