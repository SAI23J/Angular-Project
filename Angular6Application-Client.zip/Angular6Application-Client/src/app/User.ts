export class User 
{
    userid: number;
    firsname: string;
	lastnamr: String
	theater : String
	region: String
}
